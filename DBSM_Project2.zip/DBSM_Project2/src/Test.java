public class Test {
    public static void main(String[] args) {
        Operating operating = new Operating();
        operating.dbms();
    }
}