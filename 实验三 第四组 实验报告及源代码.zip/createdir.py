import datetime

with open('birthdays.txt', 'w') as f:
    start_date = datetime.date(1900, 1, 1)
    end_date = datetime.date(2099, 12, 31)
    current_date = start_date
    delta = datetime.timedelta(days=1)

    while current_date <= end_date:
        # 格式化日期字符串，低位用 0 补齐
        date_str = current_date.strftime('%Y%m%d') + '00000000'
        f.write(date_str + '\n')
        current_date += delta