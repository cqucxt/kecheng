import datetime

from Cryptodome.Cipher import AES
import binascii
cip = b'4cb17a07d4c944b9865485acddded346'
# cip=b'801a092e88dbcec2fc26ec1383728d4a'
msg = b'0000000000000000'
starttime = datetime.datetime.now () #long running

# 读取字典文件
#with open('birthdays.txt', 'r') as f:
with open('passwords2.txt', 'r') as f:
    dictionary = f.read().splitlines()



# 枚举所有口令组合
for word in dictionary:
    # 计算加盐哈希值
    print(word)
    key = bytes(word.encode())
    # print(key)
    aes = AES.new(key, AES.MODE_ECB)
    encrypted_text = aes.encrypt(msg)
    cipher = binascii.b2a_hex(encrypted_text)
    if cip == cipher:
        print("Passed")
        print(f'口令破解成功：{word}')
        break
    else:
        print("Failed")

endtime = datetime.datetime.now ()
print (endtime - starttime).seconds