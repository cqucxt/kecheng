import binascii
import datetime

from Cryptodome.Cipher import AES

starttime = datetime.datetime.now () #long running

cip = b'e566d063db81201e04ca943b36be58c2'
msg = b'0000000000000000'


# 读取字典文件
with open('passwords1.txt', 'r') as f:
    dictionary = f.read().splitlines()

# 枚举所有口令组合
for word in dictionary:
    # 计算加盐哈希值
    print(word)
    key = bytes(word.encode())
    aes = AES.new(key, AES.MODE_ECB)
    encrypted_text = aes.encrypt(msg)
    cipher = binascii.b2a_hex(encrypted_text)
    if cip == cipher:
        print("Passed")
        print(f'口令破解成功：{word}')
        break
    else:
        print("Failed")

endtime = datetime.datetime.now ()
print (endtime - starttime).seconds


