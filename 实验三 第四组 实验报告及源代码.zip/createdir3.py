from pypinyin import pinyin, Style

# 导入所需的模块和函数
from pypinyin import pinyin, Style

def chinese_to_pinyin(text):
    pinyin_list = []
    for char in text:
        pinyin_char = pinyin(char, style=Style.NORMAL)[0][0]
        pinyin_list.append(pinyin_char)
    return pinyin_list

# 读取文本文件
with open('百家姓中文.txt', 'r', encoding='utf-8') as file:
    text = file.read()

# 转换中文文本为拼音列表
surnames = chinese_to_pinyin(text)

# 选择以字母 "m" 开头的姓氏
selected_surnames = [surname for surname in surnames if surname.startswith('m')]
