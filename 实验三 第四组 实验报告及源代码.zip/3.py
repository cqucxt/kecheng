import datetime

from Cryptodome.Cipher import AES
import binascii
cip = b'30a3f4cb62e7eec4e957ebafe03adc88'
msg = b'0000000000000000'

starttime = datetime.datetime.now () #long running

# "sima,shangguan"



surnameslist = ["xin","zhao", "qian", "sun", "li", "zhou", "wu",
            "zheng", "wang", "feng", "chen", "zhu", "wei", "wei",
            "jiang", "shen", "han", "yang", "zhu", "qin", "you",
            "xu", "he", "lv", "shi", "zhang", "kong", "cao", "yan",
            "hua", "jin", "wei", "tao", "jiang", "qi", "xie", "zhou",
            "yu", "yu", "bai", "shui", "dou", "zhang", "yun", "su",
            "pan", "ge", "xi", "fan", "peng", "lang", "lu", "wei",
            "chang", "ma", "miao", "feng", "hua", "fang", "yu", "ren",
            "yuan", "liu", "feng", "bao", "shi", "tang", "fei", "lian",
            "cen", "xue", "lei", "he", "ni", "tang", "teng", "yin",
            "luo", "bi", "hao", "wu", "an", "chang", "le", "yu",
            "shi", "fu", "pi", "bian", "qi", "kang", "wu", "yu", "yuan",
            "bu", "gu", "meng", "ping", "huang", "he", "mu", "xiao", "yin",
            "yao", "shao", "zhan", "wang", "qi", "mao", "yu", "di", "mi",
            "bei", "ming", "zang", "ji", "fu", "cheng", "dai", "tan", "song",
            "mao", "pang", "xiong", "ji", "shu", "qu", "xiang", "zhu", "dong",
            "liang", "du", "ruan", "lan", "min", "xi", "ji", "ma", "qiang", "jia",
            "lu", "lou", "wei", "jiang", "tong", "yan", "guo", "mei", "sheng", "lin",
            "diao", "zhong", "xu", "qiu", "luo", "gao", "xia", "cai", "tian", "fan",
            "hu", "ling", "huo", "yu", "wan", "zhi", "ke", "zan", "guan", "lu", "mo",
            "jing", "fang", "qiu", "miao", "gan", "jie", "ying", "zong", "ding", "xuan",
            "ben", "deng", "yu", "dan", "hang", "hong", "bao", "zhu", "zuo", "shi", "cui",
            "ji", "niu", "gong", "cheng", "ji", "xing", "hua", "pei", "lu", "rong", "weng",
            "xun", "yang", "yu", "yu", "hui", "zhen", "qu", "jia", "feng", "rui", "yi", "jun",
            "ji", "ning", "ji", "song", "jing", "yue", "wu", "jiao","ba", "gong", "mu", "wei",
            "shan", "gu", "che", "hou", "mi", "peng", "quan", "xi", "ban", "yang", "qiu", "zhong",
            "yi", "gong", "ning", "qiu", "luan", "bao", "gan", "tou", "li", "rong", "zu", "wu",
            "fu", "liu", "jing", "zhan", "shu", "long", "ye", "xing", "si", "shao", "ge", "li",
            "ji", "bo", "yin", "su", "bai", "huai", "pu", "tai", "cong", "e", "suo", "xian",
            "ji", "lai", "zhuo", "lin", "tu", "meng", "chi", "qiao", "yin", "lu", "xu", "neng",
            "cang", "shuang", "wen", "xin", "dang", "zhai", "tan", "gong", "lao", "pang", "zhi",
            "yan", "chong", "mu", "lian", "ru", "xi", "huan", "ai", "yu", "rong", "xiang", "gu",
            "yi", "shen", "fu", "du", "zai", "li", "yong", "shi", "qu", "ku", "xu", "ji", "yan",
            "chong", "mu", "liang", "tu", "meng", "chi", "qiao", "yin", "lu", "xu", "neng", "cang",
            "shuang", "wen", "xin", "dang", "zhai", "tan", "gong", "lao", "pang", "shang", "nong",
            "wen", "bie", "zhuang", "yan", "chai", "ju", "yan", "chong", "mu", "lian", "ru", "xi",
            "huan", "ai", "yu", "rong", "xiang", "gu", "yi", "shen", "fu", "du", "zai", "li", "yong",
            "shi", "qu", "ku", "xu", "ji", "yan", "chong", "mu", "liang", "tu", "meng", "chi", "qiao",
            "yin", "lu", "xu", "neng", "cang", "shuang", "wen", "xin", "dang", "zhai", "tan", "gong", "lao",
            "pang", "shang", "nong", "wen", "bie", "zhuang", "yan", "chai", "ju", "shen", "gou", "ao", "rong",
            "leng", "zi", "xin", "kan", "na", "jian", "rao", "kong","zeng", "wu", "sha", "mie", "yang", "ju",
            "xu", "feng", "chao", "guan", "kuai", "xiang", "zha", "hou", "jing", "hong", "you", "zhu", "quan",
            "lu", "gai", "yi", "huan", "gong", "wanqi", "simai", "shangguan", "ouyang", "xiahou", "zhuge", "wenren",
            "dongfang", "helian", "huangfu", "weichi", "gongyang", "tantai", "gongye", "zongzheng", "puyang",
            "chunyu", "chanyu", "taishu", "shentu", "gongsun", "zhongsun", "xuanyuan", "linghu", "zhongli", "yuwen",
            "changsun", "murong", "xianyu", "lvqiu", "situ", "sikong", "qiguan", "sikou", "zhang", "du", "ziche",
            "zhuansun", "duanmu", "wuma", "gongxi", "qidiao", "lezheng", "rangsui", "gongliang", "tuoba", "jiagu",
            "zaifu", "guliang", "jin", "chu", "yan", "fa", "ru", "yan", "tu", "qin", "duanguan", "baili", "dongguo",
            "nanmen", "huyan", "gui", "hai", "yangshe", "weisheng", "yue", "shuai", "gou", "kang", "kuang", "hou", "you",
            "qin", "liangqiu", "zuoqiu", "dongmen", "ximen", "shang", "mou", "she", "er", "bo", "shang", "mou", "yu",
            "tong", "lian", "fu", "qi", "da", "nian", "ai", "yang", "tong", "yan", "fu"]


surnames=["moqi"]
surnames = [surname for surname in surnameslist if surname.startswith('m')]
print(surnames)

for surname in surnames:
    for num in range(75000000,99999999):
        ns=num%1000000

        password = surname + str(num).zfill(8)
        password += '000000' # 后面自动补齐 0，一共 16 位
        word=password[:16]
        if ns==0:
            print(word)
        key = bytes(word.encode())
        # print(key)
        aes = AES.new(key, AES.MODE_ECB)
        encrypted_text = aes.encrypt(msg)
        cipher = binascii.b2a_hex(encrypted_text)
        if cip == cipher:
            print("Passed")
            print(f'口令破解成功：{word}')
            break
        else:
            continue

endtime = datetime.datetime.now ()
c=(endtime - starttime).seconds
print(c)
