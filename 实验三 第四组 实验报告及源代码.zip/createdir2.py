# 先定义需要生成多少个百家姓与年月日的组合
n = 1000

# 百家姓列表
surnames = ['li', 'wang', 'zhang', 'liu', 'chen', 'yang', 'huang', 'zhao', 'wu', 'zhou',
            'xu', 'sun', 'ma', 'zhu', 'hu', 'guo', 'he', 'gao', 'lin', 'lu',
            'wei', 'fang', 'cheng', 'wang', 'tian', 'jiang', 'cao', 'yuan', 'deng', 'fu',
            'yu', 'xie', 'xue', 'shi', 'zou', 'pan', 'yao', 'zheng', 'long', 'han',
            'feng', 'ding', 'wei', 'xia', 'xiong', 'ren', 'cai', 'tang', 'hou', 'ruan',
            'lv', 'su', 'fei', 'gu', 'huang', 'jin', 'wei', 'tang', 'kong', 'zeng',
            'yin', 'luo', 'shen', 'duan', 'dong', 'gong', 'wen', 'liang', 'xiao', 'yang',
            'cheng', 'yin', 'jia', 'jiang', 'yu', 'hao', 'kang', 'guan', 'mu', 'qiu',
            'yan', 'chang', 'zhuang', 'yi', 'zeng', 'mo', 'bai', 'shang', 'su', 'shi',
            'chen', 'cao', 'cui', 'tao', 'jiang', 'wei', 'fan', 'cen', 'zuo', 'jiang',
            'chu', 'qian', 'ke', 'lei', 'zou', 'du', 'yi', 'mao', 'meng', 'zeng']

# 将每个氏族的第一个字母大写
# surnames = list(map(lambda x: x.capitalize(), surnames))

# 生成所有口令组合
passwords = []
for surname in surnames:
    for year in range(1950, 2020):
        for month in range(1, 13):
            for day in range(1, 32):
                password = surname + str(year) + str(month).zfill(2) + str(day).zfill(2)
                password += '000000' # 后面自动补齐 0，一共 16 位
                passwords.append(password[:16])

# 将口令组合写入 TXT 文件中
with open('passwords2.txt', 'w') as f:
    for password in passwords:
        f.write(password + '\n')

# 打印生成的口令组合数量
print(f'共生成了 {len(passwords)} 个口令组合')
