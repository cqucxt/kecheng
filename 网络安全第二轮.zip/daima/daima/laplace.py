import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

from diffprivlib.models import LogisticRegression as dpLogisticRegression
from diffprivlib.mechanisms import Laplace

# 加载AirQuality数据集
df = pd.read_csv(r"..\..\AirQualityUCI.csv",encoding='utf-8', sep=',', decimal='.', na_values=-200)
# 删除包含缺失值的行
#print(df.isnull().sum())
df.dropna(inplace=True)

# 将日期和时间列合并为单独的时间戳列，并删除原始列
df['datetime'] = pd.to_datetime(df['Date'])+pd.TimedeltaIndex(df['Time'])
df.drop(['Date','Time'], axis=1, inplace=True)

# 将时间戳列设置为索引，并按照时间排序
df.set_index('datetime', inplace=True)
df.sort_index(inplace=True)
#print(df)
# 将 CO(GT) 列转换为二元标签，大于 6.0 为异常值
df['label'] = (df['CO(GT)'] > 6.0).astype(int)
#print(df['label'])
df.drop(['CO(GT)'], axis=1, inplace=True)

# 将其他异常值替换为 NaN
df[df == -200] = np.nan

# 将特征和标签分开
X = df.drop(['label'], axis=1).values
y = df['label'].values
# print(X)
# print(y)

# X, y = load_breast_cancer(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Instantiate the Gaussian Mechanism
# epsilon =0.76 # privacy parameter
epsilon =1 # privacy parameter

sensitivity =2 # the maximum change in output due to the addition or removal of a single data point
mechanism = Laplace(epsilon=epsilon, delta=1,sensitivity = sensitivity,random_state=1)

dp_model = dpLogisticRegression(mechanism=mechanism,random_state=5)

dp_model.fit(X_train, y_train)

# Make predictions
dp_y_pred = dp_model.predict(X_test)

# Evaluate the accuracy of the differential private logistic regression model
dp_accuracy = accuracy_score(y_test, dp_y_pred)

# Compare the accuracy of the differential private logistic regression model with a non-private logistic regression model
model = LogisticRegression(random_state=5)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)

print("Accuracy of non-private logistic regression model: {:.2f}%".format(accuracy * 100))
print("Accuracy of differential private logistic regression model: {:.2f}%".format(dp_accuracy * 100))


