:mod:`diffprivlib.accountant`
=============================
.. automodule:: diffprivlib.accountant

Base class
-----------------------------
.. autoclass:: BudgetAccountant
   :members:
   :inherited-members:
   :exclude-members: slack,spent_budget,epsilon,delta
