Validation functions
=========================================================
.. automodule:: diffprivlib.validation

General functions
-----------------

.. autofunction:: check_epsilon_delta
.. autofunction:: check_bounds
.. autofunction:: clip_to_norm
.. autofunction:: clip_to_bounds
