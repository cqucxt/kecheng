
import json
import os
import sys
current_db = None
current_table = None
# url=""
# curr_path=url+"\DBMS\\"
class DBMS:
    def __init__(self):
        self.databases = {}
    def create_database(self, name):
        self.databases[name] = Database(name)
        if not os.path.exists(curr_path+name):
            os.makedirs(curr_path+name)

    def get_database(self, name):
        return self.databases.get(name)

class Database:
    def __init__(self, name):
        self.name = name
        self.tables = {}
        self.indexes = {}

    def create_table(self, name, columns):
        global current_db
        self.tables[name] = Table(name, columns)
        # 在磁盘上创建文件用于持久化数据
        with open(curr_path+'\\'+current_db.name+'\\'+name+".txt", "w") as f:
                for c in columns:
                    f.write(str(c)+" ")
                f.write('\n')

    def get_table(self, name):
        return self.tables.get(name)

    def create_index(self, table_name, column):
        index_name = f"{table_name}_{column}_index"
        
        table = self.get_table(table_name)
        if not table:
            raise ValueError(f"Table {table_name} not found")
        index = Index(index_name, table, column)
        self.indexes[index_name] = index
        for row in table.data:
            index.add(row)
        
        f= open(curr_path+'\\'+current_db.name+'\\'+index_name+".txt", "w") 
        f.write(index_name+" ")
        for col in table.columns:
            f.write(col+" ")
        f.write('\n')
        for k in index.values.keys():
            f.write(k+" ")
            temp=json.loads(json.dumps(index.values[k]).strip('[]'))
            for k_temp in temp.keys():
                f.write(temp[k_temp]+" ")
            f.write('\n')
        f.close()

    def get_index(self, name):
        return self.indexes.get(name)

class Table:
    def __init__(self, name, columns):
        self.name = name
        self.columns = columns
        self.data = []

    def insert(self, values):
        row = {}
        for i in range(len(self.columns)):
            row[self.columns[i]] = values[i].strip('(),')
        self.data.append(row)
        # print(self.data)
        f=open(curr_path+'\\'+current_db.name+'\\'+self.name+".txt", "a")#不改变原来的文件
        for v in values:
            f.write(str(v.strip('(),'))+" ")
        f.write('\n')
        f.close()
    def delete(self, condition=None):
        if condition:
            self.data = [row for row in self.data if not self.evaluate(row, condition)]
            f=open(curr_path+'\\'+current_db.name+'\\'+self.name+".txt", "w")
            for col in self.columns:
                f.write(col+' ')
            f.write('\n')
            for row in self.data:
                for t in row.values():
                    f.write(str(t)+" ")
                f.write('\n')
            f.close()
        else:
            self.data = []
            #删除已存在的table，即txt文件
            if os.path.exists(curr_path+"\\"+current_db.name+"\\"+current_table.name+".txt"):
                os.remove(curr_path+"\\"+current_db.name+"\\"+self.name+".txt")

    def update(self, values, condition=None):
        for row in self.data:
            if self.evaluate(row, condition):
                for i in range(len(self.columns)):
                    row[self.columns[i]] = values[i]
        f=open(curr_path+'\\'+current_db.name+'\\'+self.name+".txt", "w")
        for col in self.columns:
            f.write(col+' ')
        f.write('\n')
        for row in self.data:
            for t in row.values():
                f.write(str(t)+" ")
            f.write('\n')
        f.close()
        

    def select(self, columns=None, condition=None):
        if not columns: # 如果没有指定列名，则查询所有列
            columns = self.columns
        rows = []
        for row in self.data:
            if not condition or self.evaluate(row, condition):
                selected_row = {}
                for column in columns:
                    selected_row[column] = row[column]
                rows.append(selected_row)
        return rows

    def evaluate(self, row, condition):
        operator = condition[1]
        if operator == '=':
            return row[condition[0]] == condition[2]
        elif operator == '<':
            return row[condition[0]] < condition[2]
        elif operator == '>':
            return row[condition[0]] > condition[2]

class Index:#普通索引
    def __init__(self, name, table, column):
        self.name = name
        self.table = table
        self.column = column
        self.values = {}

    def add(self, row):
        key = row[self.column]
        if key in self.values:
            self.values[key].append(row)
        else:
            self.values[key] = [row]
        # print(self.values)
    def search(self, value):
        if value in self.values.keys():
            return self.values[value]
        else:
            return []

class Simulator:
    def __init__(self):
        self.dbms = DBMS()

    def execute(self, sql):
        global current_db
        global current_table
        parts = sql.strip().lower().split(' ')
        command = parts[0]
        if command == 'create':
            if parts[1] == 'database':
                self.dbms.create_database(parts[2])
                print(f"Database {parts[2]} created")
            elif parts[1] == 'table':
                name = parts[2]
                columns = [x.strip(',') for x in parts[3:] if x != '(' and x != ')']

                current_db.create_table(name, columns)
                print(f"Table {name} created")
            elif parts[1]=='index':
                current_table=current_db.get_table(parts[parts.index('on')+1])
                column = parts[parts.index('on')+2]
                current_db.create_index(current_table.name, column)
                print(f"Index created on {current_table.name}({column})")
        elif command == 'use':
            current_db = self.dbms.get_database(parts[2])
            print(f"Using database {current_db.name}")
        elif command == 'insert' :
            current_table=current_db.get_table(parts[1])
            values = parts[2:]
            # print(values)
            current_table.insert(values)
            print("Row inserted")
        elif command == 'delete' :
            # current_table=current_db.get_table(parts[1])
            if len(parts) > 2 and parts[1] == 'from':
                current_table=current_db.get_table(parts[2])
                condition = None
                where_pos = parts.index('where') if 'where' in parts else -1
                if where_pos >= 0:
                    column = parts[where_pos+1]
                    operator = parts[where_pos+2]
                    value = parts[where_pos+3]
                    condition = (column, operator, value)
                current_table.delete(condition)
                print("Rows deleted")
            else:
                current_table=current_db.get_table(parts[1])
                current_table.delete()
                print("All rows deleted")
        elif command == 'update':
            if len(parts) > 1 and parts[2] == 'set':
                current_table=current_db.get_table(parts[1])
                values = parts[3:parts.index('where')]
                condition = None
                where_pos = parts.index('where') if 'where' in parts else -1
                if where_pos >= 0:
                    column = parts[where_pos+1]
                    operator = parts[where_pos+2]
                    value = parts[where_pos+3]
                    condition = (column, operator, value)
                current_table.update(values, condition)
                print("Rows updated")
            else:
                print("Invalid syntax")
        elif command == 'select':
            from_pos=parts.index('from') if 'from' in parts else -1
            current_table=current_db.get_table(parts[from_pos+1])
            if '*' in sql:
                columns = None
            else:
                columns = parts[1:parts.index('from')]
            condition = None
            where_pos = parts.index('where') if 'where' in parts else -1
            if where_pos >= 0:
                column = parts[where_pos+1]
                operator = parts[where_pos+2]
                value = parts[where_pos+3]
                condition = (column, operator, value)
            rows = current_table.select(columns, condition)
            for row in rows:
                print(row)
        elif command =='log_out':
            print("log out success")
            sys.exit()
simulator = Simulator()
url=input("Please input your url"+'\n')
curr_path=url+"\DBMS\\"
while True:
    sql = input("SQL>")
    simulator.execute(sql)